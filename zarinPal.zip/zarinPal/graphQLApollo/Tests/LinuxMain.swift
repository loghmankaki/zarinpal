import XCTest

import graphQLApolloTests

var tests = [XCTestCaseEntry]()
tests += graphQLApolloTests.allTests()
XCTMain(tests)
