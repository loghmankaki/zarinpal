struct graphQLApollo {
    var text = "Hello, World!"
}
