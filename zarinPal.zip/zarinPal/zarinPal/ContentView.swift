//
//  ContentView.swift
//  zarinPal
//
//  Created by majid on 7/30/20.
//  Copyright © 2020 NiKa. All rights reserved.
//

import SwiftUI
import Combine


struct ContentView: View {
    @State var username: String = ""
    @State var password: String = ""
    @State var phoneNumber: String = ""

    @State var isPrivate: Bool = true
    
    //@State var notificationsEnabled: Bool = false
    @State private var repIndex = 0
    var repType = ["Private", "Public"]
    
    @State var showAction: Bool = false
    @State var showImagePicker: Bool = false
    @State var uiImage: UIImage? = nil

    //var tutors: [Tutor] = []
    var sheet: ActionSheet {
        ActionSheet(
            title: Text("Action"),
            message: Text("Quotemark"),
            buttons: [
                .default(Text("Change"), action: {
                    self.showAction = false
                    self.showImagePicker = true
                }),
                .cancel(Text("Close"), action: {
                    self.showAction = false
                }),
                .destructive(Text("Remove"), action: {
                    self.showAction = false
                    self.uiImage = nil
                })
            ])

    }

    var body: some View {
        NavigationView {
            
            VStack {
                if (uiImage == nil) {
                    Image(systemName: "camera.on.rectangle")
                        .accentColor(Color.purple)
                        .background(
                            Color.gray
                                .frame(width: 100, height: 100)
                                .cornerRadius(50))
                        .onTapGesture {
                            self.showImagePicker = true
                        }
                } else {
                    Image(uiImage: uiImage!)
                        .resizable()
                        .frame(width: 100, height: 100)
                        .cornerRadius(50)
                        .onTapGesture {
                            self.showAction = true
                        }
                }
                Spacer()
                
                Text(username)
                    .font(.title)
            Spacer()
            Form {
                Section(header: Text("PROFILE")) {
                    TextField("Username", text: $username)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    SecureField("Enter password...", text: $password)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        //.padding()

                    TextField("Enter Phone Number...", text: $phoneNumber)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                        .keyboardType(.numberPad)
                        .onReceive(Just(phoneNumber)) { newValue in
                            let filtered =  newValue.filter { "0123456789".contains($0) }
                            if filtered != newValue {
                                self.phoneNumber = filtered
                            }
                    }
                    //.padding()
                    Toggle(isOn: $isPrivate) {
                        Text("Show Phone Number")
                    }
                }
                Section(header: Text("Repository")) {
                    
                    NavigationLink(destination: repository()) {
                       Text("My Repository")
                    }.buttonStyle(BorderlessButtonStyle())
   
                    
                    Picker(selection: $repIndex, label: Text("Repository Type")) {
                        ForEach(0 ..< repType.count) {
                            Text(self.repType[$0])
                        }
                    }
                    
                    
                    
                }
                Section(header: Text("ABOUT")) {
                    HStack {
                        Text("Version")
                        Spacer()
                        Text("1.0")
                    }
                }
                Section {
                    Button(action: {
                        print("Perform an action here...")
                        self.username = ""
                        self.password = ""
                        self.phoneNumber = ""
                        self.repIndex = 0
                        
                    }) {
                        Text("Reset All Settings")
                    }
                }
            }.navigationBarTitle("Profile")
        }
        }
        .sheet(isPresented: $showImagePicker, onDismiss: {
            self.showImagePicker = false
        }, content: {
            ImagePicker(isShown: self.$showImagePicker, uiImage: self.$uiImage)
        })

        .actionSheet(isPresented: $showAction) {
            sheet
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
//        ContentView(tutors: testData)

    }
}
struct ImagePicker: UIViewControllerRepresentable {

    @Binding var isShown: Bool
    @Binding var uiImage: UIImage?

    class Coordinator: NSObject, UINavigationControllerDelegate, UIImagePickerControllerDelegate {

        @Binding var isShown: Bool
        @Binding var uiImage: UIImage?

        init(isShown: Binding<Bool>, uiImage: Binding<UIImage?>) {
            _isShown = isShown
            _uiImage = uiImage
        }

        func imagePickerController(_ picker: UIImagePickerController,
                                   didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            let imagePicked = info[UIImagePickerController.InfoKey.originalImage] as! UIImage
            uiImage = imagePicked
            isShown = false
        }

        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            isShown = false
        }

    }

    func makeCoordinator() -> Coordinator {
        return Coordinator(isShown: $isShown, uiImage: $uiImage)
    }

    func makeUIViewController(context: UIViewControllerRepresentableContext<ImagePicker>) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ uiViewController: UIImagePickerController,
                                context: UIViewControllerRepresentableContext<ImagePicker>) {

    }

}
