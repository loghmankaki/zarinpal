//
//  repDetails.swift
//  zarinPal
//
//  Created by majid on 7/30/20.
//  Copyright © 2020 NiKa. All rights reserved.
//

import SwiftUI

struct repDetails: View {
    var name: String
    var headline: String
    var description: String
    
    var body: some View {

        HStack(alignment: .lastTextBaseline) {
            VStack(){
                Image(name)
                    .clipShape(Circle())
                    .overlay(Circle().stroke(Color.orange,lineWidth: 4))
                    .shadow(radius: 10)
                Text(name)
                    .font(.title)
                Text(headline)
                    .font(.subheadline)
                Divider()
                Text(description)
                    .font(.headline)
                    .multilineTextAlignment(.center)
                .lineLimit(50)
            }.padding().navigationBarTitle(Text(name),displayMode: .inline)
        }
    }
}
#if DEBUG
struct repDetails_Previews: PreviewProvider {
    static var previews: some View {
        repDetails(name: "No item", headline: "Not availble", description: "No describtion")
    }
}
#endif

