//
//  Tutor.swift
//  Tutors
//
//  Created by Sai Kambampati on 6/5/19.
//  Copyright © 2019 AppCoda. All rights reserved.
//

import SwiftUI

struct App: Identifiable {
    var id = UUID()
    var name: String
    var headline: String
    var description: String
    
    var imageName: String { return name }
}

let testData = [
    App(name: "asharoj", headline: "home kit utility", description: "A simple app to control AshARoj artworks. AshARoj Artwork is a intelligence artwork that a bluetooth module is embed in to connect with mobile AshARoj app. A list of available AshaRoj artwork are presented in products tab."),
    App(name: "headup display car", headline: "car windshield headup display", description: "What 's HeadUp Display: (HUD) projects navigation and some information onto windshield of your car, make driving at night more safer and attractive."),
    App(name: "landMeter", headline: "offroad car slop/tilt meter", description: "landMeter indicates a graphically pitching and rolling of your car meanwhile driving, just put your iPhone on a car holder with a default angle, and keep driving, landMeter show you the slope and tilt to have safe driving in off-roads."),
    App(name: "handies", headline: "sell your hand's made product", description: "Handies-Made app as an intelligent online market brings following distinctive features to you:As a producer:        - You can create and manage your own gallery and present your artistic goods as the best way that you like.        - You can target customers from all over the world as your potential market and promote your private business effectively and shortly.        - You can be in touch with your customers and followers directly from all over the world.        As a Visitor:        Products are ranked and presented intelligently to you based on your preferences and popularity."),
    App(name: "lazerMotors", headline: "lazer automobile parts searching", description: "lazerMotors is a company which produce original automobile parts, this app help LazerMotors customer to inform them that which part name is belong to partNumber and reverse."),
    App(name: "toilet paper forcaster", headline: "calculate toilet paper usage", description: "This simple calculator shown how long your toilet stocks last,if you want to know how long your toilet paper stocks last?do you have enough toilet paper?with this application you can figure out how many days stock will last."),
    App(name: "route maker nika", headline: "record/save/share your routes", description: "People who wants to go to adventure trips in jungle, mountains, deserts or any where that there is no registered route in common navigation app need such an app to save and track the route which gone.When an adventurer track and save a route he or she can share it with others to tell them that how to go to such place on the specified route.."),
    ]
